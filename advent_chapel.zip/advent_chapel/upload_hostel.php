<?php
include 'connect.php'; // Include your database connection file

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['add_hostel'])) {
    // Retrieve form values and sanitize input
    $hostelName = isset($_POST['hostel_name']) ? $_POST['hostel_name'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';
    $location = isset($_POST['location']) ? $_POST['location'] : '';
    $distance_from_campus = isset($_POST['distance_from_campus']) ? $_POST['distance_from_campus'] : '';
    $capacity = isset($_POST['capacity']) ? $_POST['capacity'] : '';
    $price = isset($_POST['price']) ? $_POST['price'] : '';
    $occupancy = isset($_POST['occupancy']) ? $_POST['occupancy'] : '';
    $whatsapp_number = isset($_POST['whatsapp_number']) ? $_POST['whatsapp_number'] : '';
    $telephone = isset($_POST['telephone']) ? $_POST['telephone'] : '';
    $googleMapsLink = isset($_POST['google_maps_link']) ? $_POST['google_maps_link'] : '';

    // Handle multiple image uploads
    $image_paths = [];
    if (isset($_FILES['image']) && $_FILES['image']['error'][0] == UPLOAD_ERR_OK) {
        $total = count($_FILES['image']['name']);
        $uploadDir = 'uploads/';

        // Create the directory if it doesn't exist
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        for ($i = 0; $i < $total; $i++) {
            $imageTmpName = $_FILES['image']['tmp_name'][$i];
            $imageName = basename($_FILES['image']['name'][$i]);
            $uploadFile = $uploadDir . $imageName;

            if (move_uploaded_file($imageTmpName, $uploadFile)) {
                $image_paths[] = $uploadFile;
            } else {
                echo "<p>Failed to upload image: " . htmlspecialchars($imageName) . "</p>";
            }
        }
    } else {
        echo "<p>No image uploaded or there was an upload error.</p>";
    }

    // Convert the array of image paths to a JSON string
    $image_paths_json = json_encode($image_paths);

    // Check if price is empty
    if (empty($price)) {
        echo "<p>Price cannot be empty.</p>";
    } else {
        // Check for duplicate hostel
        $checkSql = "SELECT COUNT(*) FROM hostel WHERE hostel_name = ? AND location = ?";
        if ($checkStmt = $con->prepare($checkSql)) {
            $checkStmt->bind_param("ss", $hostelName, $location);
            $checkStmt->execute();
            $checkStmt->bind_result($count);
            $checkStmt->fetch();
            $checkStmt->close();

            if ($count > 0) {
                echo "<p>Hostel already exists.</p>";
            } else {
                // Prepare and execute the SQL statement
                $sql = "INSERT INTO hostel (hostel_name, description, location, distance_from_campus, capacity, price, occupancy, image_paths, whatsapp_number, google_maps_link, telephone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                if ($stmt = $con->prepare($sql)) {
                    // Bind parameters
                    $stmt->bind_param("sssdidissss", $hostelName, $description, $location, $distance_from_campus, $capacity, $price, $occupancy, $image_paths_json, $whatsapp_number, $googleMapsLink, $telephone);

                    // Execute the statement
                    if ($stmt->execute()) {
                        echo "<script>
                            alert('Hostel added successfully!');
                            window.location.href = 'dashboard.php'; // Redirect to the dashboard page
                            </script>";
                    } else {
                        echo "Error uploading hostel details: " . $stmt->error;
                    }

                    // Close the statement and connection
                    $stmt->close();
                } else {
                    echo "Error preparing statement: " . $con->error;
                }
            }
        } else {
            echo "Error preparing check statement: " . $con->error;
        }
    }

    // Close the database connection
    $con->close();
}
?>
