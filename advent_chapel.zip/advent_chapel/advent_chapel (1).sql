-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2024 at 10:56 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advent_chapel`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_management`
--

CREATE TABLE `activity_management` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `verger` varchar(255) NOT NULL,
  `treasurer` varchar(255) NOT NULL,
  `chaplain` varchar(255) NOT NULL,
  `expenses` decimal(10,2) NOT NULL,
  `received_by` varchar(255) NOT NULL,
  `brief_report` text NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `congregation_stats`
--

CREATE TABLE `congregation_stats` (
  `date` date NOT NULL,
  `congregation_male` int(11) NOT NULL,
  `congregation_female` int(11) NOT NULL,
  `congregation_total` int(11) GENERATED ALWAYS AS (`congregation_male` + `congregation_female`) STORED,
  `communicants_male` int(11) NOT NULL,
  `communicants_female` int(11) NOT NULL,
  `communicants_total` int(11) GENERATED ALWAYS AS (`communicants_male` + `communicants_female`) STORED,
  `children_male` int(11) NOT NULL,
  `children_female` int(11) NOT NULL,
  `children_total` int(11) GENERATED ALWAYS AS (`children_male` + `children_female`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `congregation_stats`
--

INSERT INTO `congregation_stats` (`date`, `congregation_male`, `congregation_female`, `communicants_male`, `communicants_female`, `children_male`, `children_female`) VALUES
('2024-10-13', 23, 11, 3, 1, 10, 6);

-- --------------------------------------------------------

--
-- Table structure for table `givings`
--

CREATE TABLE `givings` (
  `date` date NOT NULL,
  `offertory` decimal(10,2) NOT NULL,
  `thanksgiving` decimal(10,2) NOT NULL,
  `tithe` decimal(10,2) NOT NULL,
  `children` decimal(10,2) NOT NULL,
  `others` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `date` date NOT NULL,
  `activity` varchar(50) NOT NULL,
  `collect` int(8) NOT NULL,
  `leader` varchar(20) NOT NULL,
  `texts` varchar(40) NOT NULL,
  `reader` varchar(20) NOT NULL,
  `theme` int(40) NOT NULL,
  `preacher` varchar(20) NOT NULL,
  `verger` varchar(255) NOT NULL,
  `treasurer` varchar(255) NOT NULL,
  `chaplain` varchar(255) NOT NULL,
  `expenses` decimal(10,2) NOT NULL,
  `received_by` varchar(255) NOT NULL,
  `brief_report` text NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`date`, `activity`, `collect`, `leader`, `texts`, `reader`, `theme`, `preacher`, `verger`, `treasurer`, `chaplain`, `expenses`, `received_by`, `brief_report`, `remarks`) VALUES
('2024-10-07', 'Fellowship', 20000, 'amos', 'mathew ', 'james', 0, 'canon james', '', '', '', '0.00', '', '', ''),
('2024-10-09', 'fellowship', 0, 'moses', 'james 1', 'james', 0, 'moses', '', '', '', '0.00', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_management`
--
ALTER TABLE `activity_management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `congregation_stats`
--
ALTER TABLE `congregation_stats`
  ADD PRIMARY KEY (`date`);

--
-- Indexes for table `givings`
--
ALTER TABLE `givings`
  ADD PRIMARY KEY (`date`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_management`
--
ALTER TABLE `activity_management`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
