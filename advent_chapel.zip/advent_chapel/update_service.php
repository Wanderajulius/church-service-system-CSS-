<?php
// Include your database connection
include 'connect.php'; // Make sure this file contains the $con variable for database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from form
    $date = $_POST['date'];
    $activity = $_POST['activity'];
    $collect = $_POST['collect'];
    $leader = $_POST['leader'];
    $texts = $_POST['texts'];
    $reader = $_POST['reader'];
    $theme = $_POST['theme'];
    $preacher = $_POST['preacher'];
    $expenses = $_POST['expenses'];
    $brief_report = $_POST['brief_report'];
    $remarks = $_POST['remarks'];

    // Update query
    $update_query = "UPDATE activity SET 
        collect='$collect', 
        leader='$leader', 
        texts='$texts', 
        reader='$reader', 
        theme='$theme', 
        preacher='$preacher', 
        expenses='$expenses',
        brief_report='$brief_report',
        remarks='$remarks'
        
        WHERE date='$date' AND activity='$activity'";

    if ($con->query($update_query) === TRUE) {
        echo "<script>
            alert('Record updated successfully!');
            window.location.href = 'add_service.php'; // Redirect after alert
        </script>";
        exit(); // Stop further script execution
    } else {
        echo "Error updating record: " . $con->error;
    }
}

// Fetch current data to populate the form
$date = $_GET['date'];
$activity = $_GET['activity'];
$fetch_query = "SELECT * FROM activity WHERE date='$date' AND activity='$activity'";
$result = $con->query($fetch_query);
$row = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Service</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include your CSS file -->
    <style>
        h2{
text-align:center;
        }
        .form-group ,h2{
            margin-top: 15px;
        justify-content:center;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            /* margin: 15px auto; */
            width: 100%;
            justify-content:center;
        }

        .form-group input,
        .form-group select {
            width: 70%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #007bff;
            outline: none;
        }

        .submit-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }
    </style>

</head>
<body>
    <h2>Update Activities</h2>
    <form action="update_service.php" method="post" class="form-container">
    <div class="form-group">
        <input type="hidden" name="date" value="<?php echo $row['date']; ?>">
        <input type="hidden" name="activity" value="<?php echo $row['activity']; ?>">
    </div>
    <div class="form-group">
        <div>
            <label for="collect">collect:</label>
            <input type="text" name="collect" value="<?php echo $row['collect']; ?>">
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="leader">leader :</label>
            <input type="text" name="leader" value="<?php echo $row['leader']; ?>" required>
        </div>
    </div>

    <div class="form-group">
        <div>
            <label for="texts">texts :</label>
            <input type="text" name="texts" value="<?php echo $row['texts']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="reader">reader:</label>
            <input type="text" name="reader" value="<?php echo $row['reader']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="theme">theme :</label>
            <input type="text" name="theme" value="<?php echo $row['theme']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="preacher">preacher:</label>
            <input type="text" name="preacher" value="<?php echo $row['preacher']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="expenses">expenses(UGX):</label>
            <input type="text" name="expenses" value="<?php echo $row['expenses']; ?>"  onfocus="addCurrency('expenses')" onblur="removeCurrency('expenses')">
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="brief_report">brief report:</label>
            <input type="text" name="brief_report" value="<?php echo $row['brief_report']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="remarks">remarks:</label>
            <input type="text" name="remarks" value="<?php echo $row['remarks']; ?>" required>
        </div>
    </div>
    <button type="submit" class="submit-btn">Update Services</button>
    </form>
    
<script>
function addCurrency(fieldId) {
    var field = document.getElementById(fieldId);
    if (field.value === '') {
        field.value = 'UGX ';
    }
}

function removeCurrency(fieldId) {
    var field = document.getElementById(fieldId);
    if (field.value === 'UGX ') {
        field.value = '';
    }
}

function stripCurrencyPrefix() {
    const fields = ['expenses'];
    fields.forEach(fieldId => {
        var field = document.getElementById(fieldId);
        if (field.value.startsWith('UGX ')) {
            field.value = field.value.substring(4);
        }
    });
}
</script>
</body>
</html>
