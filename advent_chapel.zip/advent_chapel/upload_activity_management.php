<?php
// Include database configuration file
include 'connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $verger = $_POST['verger'];
    $treasurer = $_POST['treasurer'];
    $chaplain = $_POST['chaplain'];
    $expenses = $_POST['expenses'];
    $received_by = $_POST['received_by'];
    $brief_report = $_POST['brief_report'];
    $remarks = $_POST['remarks'];

    // Insert the data into the activity_management table
    $sql = "INSERT INTO activity_management (verger, treasurer, chaplain, expenses, received_by, brief_report, remarks) VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Prepare and execute the statement
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param('sssdsds', $verger, $treasurer, $chaplain, $expenses, $received_by, $brief_report, $remarks);

        // Check if the execution was successful
        if ($stmt->execute()) {
            echo "New record added successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js">
    
</script>


    <!-- My CSS -->
    <link rel="stylesheet" href="style.css">
      <style>
             
             button {
      background-color: #28a745; /* Green color */
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 12px; /* Round corners */
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Optional shadow */
      transition: background-color 0.3s ease; /* Smooth hover effect */
    }
    
    button:hover {
      background-color: #218838; /* Darker green on hover */
    }

        #deleteHostelButton {
            background-color: red;
            color: white;
            border: none;
            padding: 12px 18px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            margin: 7px 2px;
            cursor: pointer;
            border-radius: 6px;
            transition: background-color 0.3s ease;
        }

        #addHostelButton {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 18px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            margin: 7px 2px;
            cursor: pointer;
            border-radius: 6px;
            transition: background-color 0.3s ease;
        }
  #addHostelButton:hover {
            background-color: #45a049;
        }

        .popup {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0;
            top: 0;
            width: 70%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
             justify-content: center;
    align-items: center;
                margin-left:270px;
        }

        .popup-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 90%;
            max-width: 600px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .close-btn {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close-btn:hover,
        .close-btn:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .form-container {
            max-width: 90%;
            width: 100%;
            margin: auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input:focus {
            border-color: #007bff;
            outline: none;
        }

        .submit-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        /* Table styles */
        .hostel-details-container {
            max-height: auto; /* Adjust as needed */
            overflow-y: auto;  /* Enable vertical scrolling */
            overflow-x: auto;  /* Enable horizontal scrolling */
            border: 1px solid #ccc;
            padding: 10px;
            white-space: nowrap; /* Prevent text from wrapping, which forces horizontal scrolling */
        }

        .hostel-details {
            height: auto;
            transition: opacity 0.5s ease-in-out;
        }

        .hidden {
            opacity: 0;
            pointer-events: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            table-layout: auto;
            display: block;  /* Ensures the table can scroll */
            overflow-x: auto;
            white-space: nowrap; /* Prevent wrapping of text in columns */
        }

        th, td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: left;
            min-width: 90px; /* Set a minimum width for each column */
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Last column for action buttons */
        th:last-child, td:last-child {
            width: 90px; /* Adjust width according to the button size */
                   padding-right: 140px;
               
        }

        tr:hover {
            background-color: #ddd;
        }

        /* Dark theme */
        body.dark-theme {
            background-color: #121212;
            color: #fff;
        }

        body.dark-theme table {
            border-color: #666;
        }

        body.dark-theme th {
            background-color: #333;
        }

        body.dark-theme tr:nth-child(even) {
            background-color: #333;
        }

        body.dark-theme tr:hover {
            background-color: #444;
        }

        @media screen and (max-width: 480px) {
            .table-responsive {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            table {
                min-width: 400px;
            }
        }

        /* Slide toggle button */
        .toggle-wrapper {
            position: relative;
            width: 60px;
            height: 30px;
            background-color: #ddd;
            border-radius: 15px;
            cursor: pointer;
        }

        .toggle-handle {
            position: absolute;
            top: 50%;
            left: 2px;
            width: 26px;
            height: 26px;
            background-color: #fff;
            border-radius: 50%;
            transition: transform 0.3s ease;
        }

        .logo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 150px;
            height: auto;
            margin-top: 60px;
            margin-left: 30px;
        }

        .logo-container img {
            max-width: 100%; /* Ensure the image doesn't exceed its container's width */
            height: auto; /* Maintain aspect ratio */
        }

        .toggle-wrapper.active .toggle-handle {
            transform: translateX(30px);
        }

        /* Responsive design */
        @media screen and (max-width: 480px) {
            .form-container {
                padding: 10px;
                    width:100%;
            }

            .popup-content { 
                    margin: 5% auto; /* Reduce the margin to ensure more space for the form */
        padding: 15px; /* Reduce padding to make more room */
        width: 95%; /* Ensure it takes up most of the screen width */
        max-height: 80vh; /* Limit height to avoid going off-screen */
        overflow-y: auto; /* Allow scrolling if content is too tall */
                     overflow-x: auto;
                    
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 6px;
            }
        }

        @media screen and (max-width: 480px) {
            .toggle-wrapper {
                width: 50px;
                height: 25px;
            }

            .toggle-handle {
                width: 22px;
                height: 22px;
            }

            #addHostelButton {
                font-size: 10px;
                padding: 10px 15px;
            }

            .submit-btn {
                padding: 8px 16px;
                font-size: 14px;
                    width:100%;
            }
        }
    </style>
        
    <title>activity</title>
</head>
<body>

<?php include 'connect.php'; ?>

<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
              <div class="logo-container">
        <img src="logo.jpg" alt="Internhub Logo" width=80% ></div>
        <!--<span class="text">HostelHub</span>-->
    </a>
    <ul class="side-menu top">
        <li >
            <a href="dashboard.php">
                <i class='bx bxs-dashboard'></i>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="add_service.php" onclick="toggleApplications('bookings')">
                <i class='bx bxs-calendar-check'></i>
                <span class="text">Services</span>
            </a>
        </li>
        <li>
            <a href="upload_congregation_stats.php" onclick="toggleApplications('hostels')">
                <i class='bx bxs-home'></i>
                <span class="text">congregation</span>
            </a>
        </li>
        <li class="active"><a href="upload_activity_management.php" onclick="toggleApplications('hostels')">
                <i class='bx bxs-home'></i>
                <span class="text">Activity</span>
            </a>
        </li>
       <li> <a href="upload_givings.php" onclick="toggleApplications('hostels')">
                <i class='bx bxs-home'></i>
                <span class="text">Givings</span>
            </a>
        </li>
    </ul>
    
    <ul class="side-menu">
        <li>
            <a href="#">
                <i class='bx bxs-cog'></i>
                <span class="text">Settings</span>
            </a>
        </li>
        <li>
            <a href="admin_logout.php" class="logout">
                <i class='bx bxs-log-out-circle'></i>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</section>

<!-- SIDEBAR -->

<!-- CONTENT -->
<section id="content">
    <!-- MAIN -->
    <main>
        <div class="head-title">
            <div class="left">
                <h1>Activity</h1>
                <ul class="breadcrumb">
                    <li>
                        <a href="upload_activity_management.php">Activity</a>
                    </li>
                    <li><i class='bx bx-chevron-right'></i></li>
                    
                </ul>
            </div>
            <div class="toggle-wrapper" onclick="toggleTheme()">
                <div class="toggle-handle"></div>
            </div>
        </div>
        
      <!-- Add Hostel Form -->
      <!-- Add Hostel Button -->
 <!-- Add activity -->

    <button onclick="openPopup('addActivityManagementPopup')">Add Activity Management</button>
<div id="addHostelPopup" class="popup">
    <div class="popup-content">
        <span class="close-btn" onclick="closePopup('addHostelPopup')">&times;</span>
        <h2>Add service </h2>
        <form action="upload_hostel.php" method="post" enctype="multipart/form-data" class="form-container">
            <div class="form-group">
                <label for="Date">Date:</label>
                <input type="date" id="date" name="date" placeholder="Enter the date" required>
            </div>
            <div class="form-group">
            <label for="activity">Activity:</label>
            <select id="activity" name="activity" required>
                <option value="" disabled selected>Select an activity</option>
                <option value="Sunday Service">Sunday Service</option>
                <option value="Bible Study">Bible Study</option>
                <option value="Prayer Meeting">Prayer Meeting</option>
                <option value="Youth Fellowship">Youth Fellowship</option>
                <!-- Add more options as needed -->
            </select>
            <div class="form-group">
                <label for="LEADER">Leader:</label>
                <input type="text" id="LEADER" name="LEADER" placeholder="LEADER" required>
            </div>
            <div class="form-group">
                <label for="TEXTS">Texts:</label>
                <input type="text" id="TEXTS" name="TEXTS" placeholder="Enter texts" required>
            </div>
            <div class="form-group">
                <label for="READER">Reader:</label>
                <input type="text" id="READER" name="READER" placeholder="Enter Reader"  required>
            </div>
            <div class="form-group">
                <label for="THEME">Theme:</label>
                <input type="text" id="THEME" name="THEME" placeholder="Enter Theme"  required>
            </div>
            <div class="form-group">
                <label for="PREACHER/ FACILITATOR">Preacher/ Facilitator:</label>
                <input type="text" id="PREACHER/ FACILITATOR" name="PREACHER/ FACILITATOR" placeholder="Enter PREACHER/ FACILITATOR"  required>
            </div>
        
            <button type="submit" name="add_hostel" class="submit-btn">Add service</button>
        </form>
    </div>
</div>

<!-- congregation table -->

<div id="addStatsPopup" class="popup">
    <div class="popup-content">
        <span class="close-btn" onclick="closePopup('addStatsPopup')">&times;</span>
        <h2>Add Congregation Stats</h2>
        <form action="upload_congregation_stats.php" method="post" class="form-container">
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="congregation_male">Congregation Male:</label>
                <input type="number" id="congregation_male" name="congregation_male" required>
            </div>
            <div class="form-group">
                <label for="congregation_female">Congregation Female:</label>
                <input type="number" id="congregation_female" name="congregation_female" required>
            </div>
            <div class="form-group">
                <label for="communicants_male">Communicants Male:</label>
                <input type="number" id="communicants_male" name="communicants_male" required>
            </div>
            <div class="form-group">
                <label for="communicants_female">Communicants Female:</label>
                <input type="number" id="communicants_female" name="communicants_female" required>
            </div>
            <div class="form-group">
                <label for="children_male">Children Male:</label>
                <input type="number" id="children_male" name="children_male" required>
            </div>
            <div class="form-group">
                <label for="children_female">Children Female:</label>
                <input type="number" id="children_female" name="children_female" required>
            </div>
            <button type="submit" class="submit-btn">Add Stats</button>
        </form>
    </div>
</div>

<!-- givings table -->

<div id="addGivingsPopup" class="popup">
    <div class="popup-content">
        <span class="close-btn" onclick="closePopup('addGivingsPopup')">&times;</span>
        <h2>Add Givings</h2>
        <form action="upload_givings.php" method="post" class="form-container">
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="offertory">Offertory:</label>
                <input type="number" id="offertory" name="offertory" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="thanksgiving">Thanksgiving:</label>
                <input type="number" id="thanksgiving" name="thanksgiving" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="tithe">Tithe:</label>
                <input type="number" id="tithe" name="tithe" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="children">Children:</label>
                <input type="number" id="children" name="children" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="others">Others:</label>
                <input type="number" id="others" name="others" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="total">Total:</label>
                <input type="number" id="total" name="total" step="0.01" required>
            </div>
            <button type="submit" class="submit-btn">Add Givings</button>
        </form>
    </div>
</div>

<!-- activity table -->

<div id="addActivityManagementPopup" class="popup">
    <div class="popup-content">
        <span class="close-btn" onclick="closePopup('addActivityManagementPopup')">&times;</span>
        <h2>Add Activity Management</h2>
        <form action="upload_activity_management.php" method="post" class="form-container">
            <div class="form-group">
                <label for="verger">Verger:</label>
                <input type="text" id="verger" name="verger" placeholder="Enter Verger" required>
            </div>
            <div class="form-group">
                <label for="treasurer">Treasurer:</label>
                <input type="text" id="treasurer" name="treasurer" placeholder="Enter Treasurer" required>
            </div>
            <div class="form-group">
                <label for="chaplain">Chaplain:</label>
                <input type="text" id="chaplain" name="chaplain" placeholder="Enter Chaplain" required>
            </div>
            <div class="form-group">
                <label for="expenses">Expenses:</label>
                <input type="number" id="expenses" name="expenses" step="0.01" placeholder="Enter Expenses" required>
            </div>
            <div class="form-group">
                <label for="received_by">Received By:</label>
                <input type="text" id="received_by" name="received_by" placeholder="Enter Received By" required>
            </div>
            <div class="form-group">
                <label for="brief_report">Brief Report:</label>
                <textarea id="brief_report" name="brief_report" placeholder="Enter Brief Report" required></textarea>
            </div>
            <div class="form-group">
                <label for="remarks">Remarks:</label>
                <textarea id="remarks" name="remarks" placeholder="Enter Remarks" required></textarea>
            </div>
            <button type="submit" class="submit-btn">Add Activity Management</button>
        </form>
    </div>
</div>

<script>
    function closePopup(popupId) {
        document.getElementById(popupId).style.display = 'none';
    }
</script>


        <?php
// Include database connection file
include 'connect.php';

// Initialize variables to store counts
$numBookings = 0;
// $numHostels = 0;
$numStudents = 0;

// Fetch number of bookings
$bookings_query = "SELECT COUNT(*) AS numBookings FROM congregation_stats";
$bookings_result = $con->query($bookings_query);
if ($bookings_result) {
    $bookings_row = $bookings_result->fetch_assoc();
    $numBookings = $bookings_row["numBookings"];
} else {
    die("Error fetching bookings: " . $con->error);
}

// Fetch number of hostels
$hostels_query = "SELECT COUNT(*) AS numHostels FROM givings ";
$hostels_result = $con->query($hostels_query);
if ($hostels_result) {
    $hostels_row = $hostels_result->fetch_assoc();
    $numHostels = $hostels_row["numHostels"];
} else {
    die("Error fetching hostels: " . $con->error);
}

// Fetch number of students
$students_query = "SELECT COUNT(*) AS numStudents FROM activity_management";
$students_result = $con->query($students_query);
if ($students_result) {
    $students_row = $students_result->fetch_assoc();
    $numStudents = $students_row["numStudents"];
} else {
    die("Error fetching students: " . $con->error);
}
?>



        <!-- Display fetched data -->
        <div id="givings-section" class="details-section" style="display: none;">
    <h2>Givings</h2>
    <table class="styled-table" id="givings-table">
        <thead>
            <tr>
                <th>Offertory</th>
                <th>Thanksgiving</th>
                <th>Tithe</th>
                <th>Children</th>
                <th>Others</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $givings_details_query = "SELECT * FROM givings";
            $givings_details_result = $con->query($givings_details_query);
            if ($givings_details_result->num_rows > 0) {
                while ($row = $givings_details_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["offertory"] . "</td>";
                    echo "<td>" . $row["thanksgiving"] . "</td>";
                    echo "<td>" . $row["tithe"] . "</td>";
                    echo "<td>" . $row["children"] . "</td>";
                    echo "<td>" . $row["others"] . "</td>";
                    echo "<td>" . $row["total"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No givings found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<div id="activityManagement-section" class="details-section" style="display: none;">
    <h2>Activity Management</h2>
    <table class="styled-table" id="activity-management-table">
        <thead>
            <tr>
                <th>Verger</th>
                <th>Treasurer</th>
                <th>Chaplain</th>
                <th>Expenses</th>
                <th>Received By</th>
                <th>Brief Report</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $activity_management_query = "SELECT * FROM activity_management";
            $activity_management_result = $con->query($activity_management_query);
            if ($activity_management_result->num_rows > 0) {
                while ($row = $activity_management_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["verger"] . "</td>";
                    echo "<td>" . $row["treasurer"] . "</td>";
                    echo "<td>" . $row["chaplain"] . "</td>";
                    echo "<td>" . $row["expenses"] . "</td>";
                    echo "<td>" . $row["received_by"] . "</td>";
                    echo "<td>" . $row["brief_report"] . "</td>";
                    echo "<td>" . $row["remarks"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No activities found</td></tr>";
            }
            ?>
        </tbody>
    </table>


        <!-- Hostels Details -->
        <div class="approved-internships" style="display: none;">
            <h2 id="approved-header">Hostels</h2>
            <!-- Display hostels details here -->
            <!-- Example: Table showing hostels details -->
            <button onclick="openPopup('addHostelPopup')">Add Hostel</button>
            <table class="styled-table" id="hostels-table">
                <thead>
                <tr>
                    <th>Hostel ID</th>
                    <th>Hostel Name</th>
                    <th>Location</th>
                    <th>distance</th>
                    <th>price</th>
                    <th>Capacity</th>
                    <th>Occupancy</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <!-- Fetch and display hostels details dynamically -->
                <?php
$num_hostels_details_query = "SELECT * FROM hostel";
$num_hostels_details_result = $con->query($num_hostels_details_query);
if ($num_hostels_details_result->num_rows > 0) {
    while ($row = $num_hostels_details_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["hostel_id"] . "</td>";
        echo "<td>" . $row["hostel_name"] . "</td>";
        echo "<td>" . $row["location"] . "</td>";
        echo "<td>" . $row["distance_from_campus"] . "</td>";
        echo "<td>" . $row["price"] . "</td>";
        echo "<td>" . $row["capacity"] . "</td>";
        echo "<td>" . $row["occupancy"] . "</td>";
        echo "<td>";
        echo "<button onclick=\"openPopup('updateHostelPopup', '{$row["hostel_id"]}', '{$row["hostel_name"]}', '{$row["location"]}', '{$row["capacity"]}', '{$row["price"]}', '{$row["occupancy"]}')\">Update</button>";
        echo "<button onclick=\"openPopup('deleteHostelPopup', '{$row["hostel_id"]}', '{$row["hostel_name"]}')\">Delete</button>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7'>No hostels found</td></tr>";
}
?>


                </tbody>
            </table>
        </div>

       
        
                
                <!-- The Popup -->
                <div id="studentsPopup" class="popup">
                    <div class="popup-content">
                        <span class="close-btn" id="closePopupBtn">&times;</span>
                        <h2>Users Details</h2>
                        <table border="1">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Email</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                $students_details_query = "SELECT * FROM booking";
                $students_details_result = $con->query($students_details_query);
                if ($students_details_result->num_rows > 0) {
                    while ($row = $students_details_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["username"] . "</td>";
                        echo "<td>" . $row["email"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='2'>No users found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
                                <?php
                
                // Check if the form was submitted
if (isset($_POST['add_hostel'])) {
    // Retrieve form data
    $hostel_name = $con->real_escape_string($_POST['hostel_name']);
    $location = $con->real_escape_string($_POST['location']);
    $capacity = intval($_POST['capacity']);
    $occupancy = intval($_POST['occupancy']);
    
    // Insert new hostel into the database
    $add_hostel_query = "INSERT INTO hostels (hostel_name, location, capacity, occupancy) VALUES ('$hostel_name', '$location', $capacity, $occupancy)";
    
    if ($con->query($add_hostel_query)) {
        echo "<p>Hostel added successfully!</p>";
    } else {
        echo "<p>Error adding hostel: " . $con->error . "</p>";
    }
}
                ?>
                </tbody>
            </table>
        </div>

        <!-- Number of Hostels Details -->
        <div class="num-hostels-details" style="display: none;">
            <h2>Number of Hostels</h2>
            <!-- Display number of hostels details here -->
            <!-- Example: Table showing number of hostels details -->
            <table class="styled-table" id="num-hostels-table">
                <thead>
                <tr>
                    <th>Hostel ID</th>
                    <th>Hostel Name</th>
                    <th>Location</th>
                    <th>Capacity</th>
                    <th>Occupancy</th>
                </tr>
                </thead>
                <tbody>
                <!-- Fetch and display number of hostels details dynamically -->
                <?php
                $num_hostels_details_query = "SELECT * FROM hostel";
                $num_hostels_details_result = $con->query($num_hostels_details_query);
                if ($num_hostels_details_result->num_rows > 0) {
                    while ($row = $num_hostels_details_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["hostel_name"] . "</td>";
                        echo "<td>" . $row["location"] . "</td>";
                        echo "<td>" . $row["capacity"] . "</td>";
                        echo "<td>" . $row["price"] . "</td>";
                        echo "<td>" . $row["occupancy"] . "</td>";
                        
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No hostels found</td></tr>";
                }
                ?>
                </tbody>
            </table>
        </div>

    </main>
    <!-- MAIN -->
</section>
<!-- CONTENT -->

<script>
    function toggleTheme() {
        document.body.classList.toggle('dark-theme');
        document.querySelector('.toggle-wrapper').classList.toggle('active');
    }

    // Toggle Applications
    function toggleApplications(type) {
        var bookingsDetails = document.querySelector('.application-details');
        var hostelsDetails = document.querySelector('.approved-internships');

        bookingsDetails.style.display = 'none';
        hostelsDetails.style.display = 'none';

        if (type === 'bookings') {
            bookingsDetails.style.display = 'block';
        } else if (type === 'hostels') {
            hostelsDetails.style.display = 'block';
        }
    }
    // Toggle Add Hostel Form
function toggleAddHostel() {
    var addHostelForm = document.querySelector('.add-hostel');
    addHostelForm.style.display = addHostelForm.style.display === 'none' ? 'block' : 'none';
}


    // Toggle Visitors
    function toggleVisitors(type) {
        var studentsDetails = document.querySelector('.visitors-details');
        var numHostelsDetails = document.querySelector('.num-hostels-details');

        studentsDetails.style.display = 'none';
        numHostelsDetails.style.display = 'none';

        if (type === 'students') {
            studentsDetails.style.display = 'block';
        } else if (type === 'numHostels') {
            numHostelsDetails.style.display = 'block';
        }
    }
    
    // function approveBooking(bookingId) {
    //     if (confirm('Are you sure you want to approve this booking?')) {
    //         // Make an AJAX request to approve the booking
    //         var xhr = new XMLHttpRequest();
    //         xhr.open("POST", "approve_booking.php", true);
    //         xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    //         xhr.onreadystatechange = function() {
    //             if (xhr.readyState === 4 && xhr.status === 200) {
    //                 alert('Booking approved successfully!');
    //                 location.reload(); // Reload the page to see the changes
    //             }
    //         };
    //         xhr.send("booking_id=" + bookingId);
    //     }
    // }

    
function approveBooking(bookingId) {
    if (confirm("Are you sure you want to approve this booking?")) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "approve_booking.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                alert(xhr.responseText);
                location.reload(); // Reload the page to see the changes
            }
        };
        xhr.send("booking_id=" + bookingId);
    }
}



    // Function to approve booking
    // function approveBooking(bookingId) {
        // Send AJAX request to approve_booking.php
        // console.log("Booking ID: " + bookingId + " approved!");
        // Example: Implement AJAX call to update booking status
    // }
    // Function to toggle Manage Hostels visibility
function toggleManageHostels() {
    var manageHostelsSection = document.querySelector('.manage-hostels');
    manageHostelsSection.style.display = manageHostelsSection.style.display === 'none' ? 'block' : 'none';
}
// Get the modal
var popup = document.getElementById("studentsPopup");

// Get the button that opens the modal
var btn = document.getElementById("openPopupBtn");

// Get the <span> element that closes the modal
var span = document.getElementById("closePopupBtn");

// When the user clicks the button, open the modal 
btn.onclick = function() {
    popup.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    popup.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == popup) {
        popup.style.display = "none";
    }
}
function openPopup(popupId) {
            document.getElementById(popupId).style.display = 'block';
        }

        function closePopup(popupId) {
            document.getElementById(popupId).style.display = 'none';
        }
        function openPopup(popupId, id, name = '', location = '', capacity = '', price = '', occupancy = '') {
    if (popupId === 'updateHostelPopup') {
        document.getElementById('update_hostel_id').value = id;
        document.getElementById('update_hostel_name').value = name;
        document.getElementById('update_location').value = location;
        document.getElementById('update_capacity').value = capacity;
        document.getElementById('update_price').value = price;
        document.getElementById('update_occupancy').value = occupancy;
    }

    if (popupId === 'deleteHostelPopup') {
        document.getElementById('delete_hostel_id').value = id;
        document.getElementById('delete_message').innerText = `Are you sure you want to delete hostel ${name}?`;
    }

    document.getElementById(popupId).style.display = 'block';
}

function closePopup(popupId) {
    document.getElementById(popupId).style.display = 'none';
}
function showSection(sectionId) {
        // Hide all sections
        var sections = document.querySelectorAll('.section-content');
        sections.forEach(function(section) {
            section.classList.remove('active-section');
        });

        // Show the selected section
        document.getElementById(sectionId).classList.add('active-section');
    }
    function toggleApplications(section) {
    // Hide the box-info
    document.querySelector('.box-info').style.display = 'none';

    // Hide all sections first
    document.getElementById('bookings-section').style.display = 'none';
    document.getElementById('hostels-section').style.display = 'none';
    document.getElementById('students-section').style.display = 'none';

    // Show the selected section
    if (section === 'bookings') {
        document.getElementById('bookings-section').style.display = 'block';
    } else if (section === 'hostels') {
        document.getElementById('hostels-section').style.display = 'block';
    } else if (section === 'students') {
        document.getElementById('students-section').style.display = 'block';
    }
}
</script>

</body>
</html>


