<?php
// Include database configuration file
include 'connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $date = $_POST['date'];
    $activity = $_POST['activity'];
    $congregation_male = $_POST['congregation_male'];
    $congregation_female = $_POST['congregation_female'];
    $communicants_male = $_POST['communicants_male'];
    $communicants_female = $_POST['communicants_female'];
    $children_male = $_POST['children_male'];
    $children_female = $_POST['children_female'];

    // Insert the data into the congregation_stats table
    $sql = "INSERT INTO congregation_stats (date,activity, congregation_male, congregation_female, communicants_male, communicants_female, children_male, children_female) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and execute the statement
    if ($stmt = $con->prepare($sql)) {
        $stmt->bind_param('ssiiiiii', $date, $activity,$congregation_male, $congregation_female, $communicants_male, $communicants_female, $children_male, $children_female);

        // Check if the execution was successful
        if ($stmt->execute()) {
            echo "<script>
                alert('Record added successfuly!');
                </script>";
        }else {
            echo "Error adding details: " . $stmt->error;
        }
        // Close the statement
        $stmt->close();
    } else {
        echo "Error: " . $con->error;
    }

    // Close the conection
    $con->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js">
    
</script>


    <!-- My CSS -->
    <link rel="stylesheet" href="style.css">
      <style>
             
     
             button, .update-btn {
      background-color: #009879; /* Green color */
      color: white;
      border: none;
      padding: 10px 15px;
      border-radius: 12px; /* Round corners */
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Optional shadow */
      transition: background-color 0.3s ease; /* Smooth hover effect */
    }
    .delete-btn{
        margin-left:10px;
        background-color:red;
        color: white;
      border: none;
      padding: 10px 15px;
      border-radius: 12px; /* Round corners */
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Optional shadow */
      transition: background-color 0.3s ease; /* Smooth hover effect */

    }
    
    button:hover,.update-btn {
      background-color: #218838; /* Darker green on hover */}

        .popup {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0;
            top: 0;
            width: 70%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
             justify-content: center;
    align-items: center;
                margin-left:270px;
        }

        .popup-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 90%;
            max-width: 600px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .close-btn {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close-btn:hover,
        .close-btn:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .form-container {
            max-width: 90%;
            width: 100%;
            margin: auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input:focus {
            border-color: #007bff;
            outline: none;
        }

        .submit-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        /* Table styles */
        .hostel-details-container {
            max-height: auto; /* Adjust as needed */
            overflow-y: auto;  /* Enable vertical scrolling */
            overflow-x: auto;  /* Enable horizontal scrolling */
            border: 1px solid #ccc;
            padding: 10px;
            white-space: nowrap; /* Prevent text from wrapping, which forces horizontal scrolling */
        }

        .hostel-details {
            height: auto;
            transition: opacity 0.5s ease-in-out;
        }

        .hidden {
            opacity: 0;
            pointer-events: none;
        }

        .styled-table {
            width: 100%;
            border-collapse: collapse;
            padding-left:10px
            
            
        }

        .styled-table thead tr {
            background-color: #009879;
            color: white;
            text-align: left;
        }

        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
            border: 1px solid #dddddd;
        }

        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
       
        /* Dark theme */
        body.dark-theme {
            background-color: #121212;
            color: #fff;
        }

        body.dark-theme table {
            border-color: #666;
        }

        body.dark-theme th {
            background-color: #333;
        }

        body.dark-theme tr:nth-child(even) {
            background-color: #333;
        }

        body.dark-theme tr:hover {
            background-color: #444;
        }

        @media screen and (max-width: 480px) {
            .table-responsive {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            table {
                min-width: 400px;
            }
        }

        /* Slide toggle button */
        .toggle-wrapper {
            position: relative;
            width: 60px;
            height: 30px;
            background-color: #ddd;
            border-radius: 15px;
            cursor: pointer;
        }

        .toggle-handle {
            position: absolute;
            top: 50%;
            left: 2px;
            width: 26px;
            height: 26px;
            background-color: #fff;
            border-radius: 50%;
            transition: transform 0.3s ease;
        }

        .logo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 150px;
            height: auto;
            margin-top: 60px;
            margin-left: 30px;
        }

        .logo-container img {
            max-width: 100%; /* Ensure the image doesn't exceed its container's width */
            height: auto; /* Maintain aspect ratio */
        }

        .toggle-wrapper.active .toggle-handle {
            transform: translateX(30px);
        }

        /* Responsive design */
        @media screen and (max-width: 480px) {
            .form-container {
                padding: 10px;
                    width:100%;
            }

            .popup-content { 
                    margin: 5% auto; /* Reduce the margin to ensure more space for the form */
        padding: 15px; /* Reduce padding to make more room */
        width: 95%; /* Ensure it takes up most of the screen width */
        max-height: 80vh; /* Limit height to avoid going off-screen */
        overflow-y: auto; /* Allow scrolling if content is too tall */
                     overflow-x: auto;
                    
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 6px;
            }
        }

        @media screen and (max-width: 480px) {
            .toggle-wrapper {
                width: 50px;
                height: 25px;
            }

            .toggle-handle {
                width: 22px;
                height: 22px;
            }

            #addHostelButton {
                font-size: 10px;
                padding: 10px 15px;
            }

            .submit-btn {
                padding: 8px 16px;
                font-size: 14px;
                    width:100%;
            }
        }
    </style>
        
    <title>Congregation</title>
</head>
<body>

<?php include 'connect.php'; ?>

<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
              <div class="logo-container">
        <img src="logo.jpg" alt="Internhub Logo" width=80% ></div>
        <!--<span class="text">HostelHub</span>-->
    </a>
    <ul class="side-menu top">
        <li >
            <a href="dashboard.php">
                <i class='bx bxs-dashboard'></i>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <li >
            <a href="add_service.php" onclick="toggleApplications('bookings')">
                <i class='bx bxs-calendar-check'></i>
                <span class="text">Activities</span>
            </a>
        </li>
        <li class="active">
        <a href="upload_congregation_stats.php" onclick="toggleApplications('hostels')">
            <i class='bx bxs-group'></i>
                <span class="text">congregation</span>
            </a>
        </li>
               <li > <a href="upload_givings.php" onclick="toggleApplications('hostels')">
               <i class='bx bxs-donate-heart'></i>
                <span class="text">Givings</span>
            </a>
        </li>
    </ul>
    
    <ul class="side-menu">
        <li>
            <a href="#">
                <i class='bx bxs-cog'></i>
                <span class="text">Settings</span>
            </a>
        </li>
        <li>
            <a href="admin_logout.php" class="logout">
                <i class='bx bxs-log-out-circle'></i>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</section>

<!-- SIDEBAR -->

<!-- CONTENT -->
<section id="content">
    <!-- MAIN -->
    <main>
        <div class="head-title">
            <div class="left">
                <h1>Congregation</h1>
                <ul class="breadcrumb">
                    <li>
                        <a href="upload_congregation_stats.php">congregation</a>
                    </li>
                    <li><i class='bx bx-chevron-right'></i></li>
                    
                </ul>
            </div>
            <div class="toggle-wrapper" onclick="toggleTheme()">
                <div class="toggle-handle"></div>
            </div>
        </div>
        
      <!-- Add CONGREGATION BUTTON -->

 <button onclick="openPopup('addStatsPopup')">Add Congregation Stats</button>
    <div id="addHostelPopup" class="popup">
    <div class="popup-content">
        <span class="close-btn" onclick="closePopup('addHostelPopup')">&times;</span>
        <h2>Add service </h2>
        <form action="upload_congregation_stats.php" method="post" enctype="multipart/form-data" class="form-container">
            <div class="form-group">
                <label for="Date">Date:</label>
                <input type="date" id="date" name="date" placeholder="Enter the date" required>
            </div>
            <div class="form-group">
                <label for="ACTIVITY">activity:</label>
                <input type="text" id="ACTIVITY" name="ACTIVITY" placeholder="Enter activity" required>
            </div>
            <div class="form-group">
                <label for="LEADER">LEADER:</label>
                <input type="text" id="LEADER" name="LEADER" placeholder="LEADER" required>
            </div>
            <div class="form-group">
                <label for="TEXTS">Texts:</label>
                <input type="text" id="TEXTS" name="TEXTS" placeholder="Enter texts" required>
            </div>
            <div class="form-group">
                <label for="READER">READER:</label>
                <input type="text" id="READER" name="READER" placeholder="Enter Reader"  required>
            </div>
            <div class="form-group">
                <label for="THEME">THEME:</label>
                <input type="text" id="THEME" name="THEME" placeholder="Enter Theme"  required>
            </div>
            <div class="form-group">
                <label for="PREACHER/ FACILITATOR">PREACHER/ FACILITATOR:</label>
                <input type="text" id="PREACHER/ FACILITATOR" name="PREACHER/ FACILITATOR" placeholder="Enter PREACHER/ FACILITATOR"  required>
            </div>
        
            <button type="submit" name="add_hostel" class="submit-btn">Add service</button>
        </form>
    </div>
</div>

<!-- congregation table -->

<div id="addStatsPopup" class="popup">
    <div class="popup-content">
        <span class="close-btn" onclick="closePopup('addStatsPopup')">&times;</span>
        <h2>Add Congregation Stats</h2>
        <form action="upload_congregation_stats.php" method="post" class="form-container">
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group">
            <label for="activity">Activity:</label>
            <select id="activity" name="activity" required>
                <option value="" disabled selected>Select an activity</option>
                <option value="Sunday Service">Sunday Service</option>
                <option value="Bible Study">Bible Study</option>
                <option value="Prayer Meeting">Prayer Meeting</option>
                <option value="Youth Fellowship">Youth Fellowship</option>
                <!-- Add more options as needed -->
            </select>
    </div>

            <div class="form-group">
                <label for="congregation_male">Congregation Male:</label>
                <input type="number" id="congregation_male" name="congregation_male" required>
            </div>
            <div class="form-group">
                <label for="congregation_female">Congregation Female:</label>
                <input type="number" id="congregation_female" name="congregation_female" required>
            </div>
            <div class="form-group">
                <label for="communicants_male">Communicants Male:</label>
                <input type="number" id="communicants_male" name="communicants_male">
            </div>
            <div class="form-group">
                <label for="communicants_female">Communicants Female:</label>
                <input type="number" id="communicants_female" name="communicants_female">
            </div>
            <div class="form-group">
                <label for="children_male">Children Male:</label>
                <input type="number" id="children_male" name="children_male" required>
            </div>
            <div class="form-group">
                <label for="children_female">Children Female:</label>
                <input type="number" id="children_female" name="children_female" required>
            </div>
            <button type="submit" class="submit-btn">Add Stats</button>
        </form>
    </div>
</div>


<script>
    function closePopup(popupId) {
        document.getElementById(popupId).style.display = 'none';
    }
</script>


        <?php
// Include database connection file
include 'connect.php';
?>

        <!-- Display fetched data -->

<div id="activityManagement-section" class="details-section" >
    <h2>Congregation</h2>
    <table class="styled-table" id="activity-management-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Activity</th>
                <th>Congregation Male</th>
                <th>Congregation Female</th>
                <th>Communicants Male</th>
                <th>Communicants Female</th>
                <th>Children Male</th>
                <th>Children Female</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $activity_management_query = "SELECT * FROM congregation_stats";
            $activity_management_result = $con->query($activity_management_query);
            if ($activity_management_result->num_rows > 0) {
                while ($row = $activity_management_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["date"] . "</td>";
                    echo "<td>" . htmlspecialchars($row['activity']) . "</td>";
                    echo "<td>" . $row["congregation_male"] . "</td>";
                    echo "<td>" . $row["congregation_female"] . "</td>";
                    echo "<td>" . $row["communicants_male"] . "</td>";
                    echo "<td>" . $row["communicants_female"] . "</td>";
                    echo "<td>" . $row["children_male"] . "</td>";
                    echo "<td>" . $row["children_female"] . "</td>";
                    echo "<td>";
                    echo "<a href='update_congregation.php?date=" . urlencode($row["date"]) . "&activity=" . urlencode($row["activity"]) . "' class='update-btn'>Update</a>";
                    echo "<a href='delete_congregation.php?date=" . urlencode($row["date"]) . "&activity=" . urlencode($row["activity"]) . "' class='delete-btn' onclick='return confirm(\"Are you sure you want to delete this record?\");'>Delete</a>";
                    echo "</td>";

                    echo "</tr>";
    
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No stats found</td></tr>";
            }
            ?>
        </tbody>
    </table>


    </main>
    <!-- MAIN -->
</section>
<!-- CONTENT -->

<script>
    function toggleTheme() {
        document.body.classList.toggle('dark-theme');
        document.querySelector('.toggle-wrapper').classList.toggle('active');
    }

    // Toggle Applications
    function toggleApplications(type) {
        var bookingsDetails = document.querySelector('.application-details');
        var hostelsDetails = document.querySelector('.approved-internships');

        bookingsDetails.style.display = 'none';
        hostelsDetails.style.display = 'none';

        if (type === 'bookings') {
            bookingsDetails.style.display = 'block';
        } else if (type === 'hostels') {
            hostelsDetails.style.display = 'block';
        }
    }
    // Toggle Add Hostel Form
function toggleAddHostel() {
    var addHostelForm = document.querySelector('.add-hostel');
    addHostelForm.style.display = addHostelForm.style.display === 'none' ? 'block' : 'none';
}


function toggleManageHostels() {
    var manageHostelsSection = document.querySelector('.manage-hostels');
    manageHostelsSection.style.display = manageHostelsSection.style.display === 'none' ? 'block' : 'none';
}
// Get the modal
var popup = document.getElementById("studentsPopup");

// Get the button that opens the modal
var btn = document.getElementById("openPopupBtn");

// Get the <span> element that closes the modal
var span = document.getElementById("closePopupBtn");

// When the user clicks the button, open the modal 
btn.onclick = function() {
    popup.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    popup.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == popup) {
        popup.style.display = "none";
    }
}
function openPopup(popupId) {
            document.getElementById(popupId).style.display = 'block';
        }

        function closePopup(popupId) {
            document.getElementById(popupId).style.display = 'none';
        }
        function openPopup(popupId, id, name = '', location = '', capacity = '', price = '', occupancy = '') {
    if (popupId === 'updateHostelPopup') {
        document.getElementById('update_hostel_id').value = id;
        document.getElementById('update_hostel_name').value = name;
        document.getElementById('update_location').value = location;
        document.getElementById('update_capacity').value = capacity;
        document.getElementById('update_price').value = price;
        document.getElementById('update_occupancy').value = occupancy;
    }

    if (popupId === 'deleteHostelPopup') {
        document.getElementById('delete_hostel_id').value = id;
        document.getElementById('delete_message').innerText = `Are you sure you want to delete hostel ${name}?`;
    }

    document.getElementById(popupId).style.display = 'block';
}

function closePopup(popupId) {
    document.getElementById(popupId).style.display = 'none';
}
function showSection(sectionId) {
        // Hide all sections
        var sections = document.querySelectorAll('.section-content');
        sections.forEach(function(section) {
            section.classList.remove('active-section');
        });

        // Show the selected section
        document.getElementById(sectionId).classList.add('active-section');
    }
    function toggleApplications(section) {
    // Hide the box-info
    document.querySelector('.box-info').style.display = 'none';

    // Hide all sections first
    document.getElementById('bookings-section').style.display = 'none';
    document.getElementById('hostels-section').style.display = 'none';
    document.getElementById('students-section').style.display = 'none';

    // Show the selected section
    if (section === 'bookings') {
        document.getElementById('bookings-section').style.display = 'block';
    } else if (section === 'hostels') {
        document.getElementById('hostels-section').style.display = 'block';
    } else if (section === 'students') {
        document.getElementById('students-section').style.display = 'block';
    }
}
</script>

</body>
</html>


