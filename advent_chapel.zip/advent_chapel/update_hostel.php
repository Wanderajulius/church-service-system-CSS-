<?php
include 'connect.php'; // Include the database connection file

if (isset($_POST['update_hostel'])) {
    // Retrieve form data
    $hostel_id = $_POST['hostel_id'];

    // Initialize an array to hold the update fields and parameters
    $update_fields = [];
    $params = [];
    $types = "";

    // Helper function to add a field to the update query
    function add_update_field($field, $value, &$update_fields, &$params, &$types, $type) {
        if (!empty($value)) {
            $update_fields[] = "$field = ?";
            $params[] = $value;
            $types .= $type;
        }
    }

    // Add fields to the update query if they are provided
    add_update_field("hostel_name", $_POST['hostel_name'], $update_fields, $params, $types, "s");
    add_update_field("description", $_POST['description'], $update_fields, $params, $types, "s");
    add_update_field("location", $_POST['location'], $update_fields, $params, $types, "s");
    add_update_field("distance_from_campus", $_POST['distance_from_campus'], $update_fields, $params, $types, "d");
    add_update_field("capacity", $_POST['capacity'], $update_fields, $params, $types, "i");
    add_update_field("price", $_POST['price'], $update_fields, $params, $types, "i");
    add_update_field("occupancy", $_POST['occupancy'], $update_fields, $params, $types, "s");
    add_update_field("whatsapp_number", $_POST['whatsapp_number'], $update_fields, $params, $types, "s");
    add_update_field("google_maps_link", $_POST['google_maps_link'], $update_fields, $params, $types, "s");
    add_update_field("telephone", $_POST['telephone'], $update_fields, $params, $types, "s");

    // Handle multiple image uploads if new images were provided
    if (isset($_FILES['image']) && $_FILES['image']['error'][0] == 0) {
        $total = count($_FILES['image']['name']);
        $image_folder = 'uploads/';

        // Create the directory if it doesn't exist
        if (!is_dir($image_folder)) {
            mkdir($image_folder, 0777, true);
        }

        $image_paths = [];
        for ($i = 0; $i < $total; $i++) {
            $image_name = $_FILES['image']['name'][$i];
            $image_tmp_name = $_FILES['image']['tmp_name'][$i];
            $image_path = $image_folder . basename($image_name);

            if (move_uploaded_file($image_tmp_name, $image_path)) {
                $image_paths[] = $image_path;
            } else {
                die("Failed to upload image: " . $image_name);
            }
        }
        $image_paths_json = json_encode($image_paths);
        add_update_field("image_paths", $image_paths_json, $update_fields, $params, $types, "s");
    }

    // Proceed with the update if there are any fields to update
    if (count($update_fields) > 0) {
        // Add hostel_id to the params and types
        $params[] = $hostel_id;
        $types .= "i";

        // Prepare the SQL query
        $update_query = "UPDATE hostel SET " . implode(", ", $update_fields) . " WHERE hostel_id = ?";
        $stmt = $con->prepare($update_query);

        // Bind the parameters dynamically
        $stmt->bind_param($types, ...$params);

        // Execute the update
        if ($stmt->execute()) {
            echo "<script>
                alert('Hostel details updated successfully.');
                window.location.href = 'dashboard.php'; // Redirect to the dashboard page
                </script>";
        } else {
            echo "Error updating hostel details: " . $stmt->error;
        }

        // Close the statement and connection
        $stmt->close();
        $con->close();
    } else {
        echo "No fields to update.";
    }
} else {
    echo "Invalid request.";
}
?>
