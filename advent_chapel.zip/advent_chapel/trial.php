<?php
// Include database configuration file
include 'connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $date = $_POST['date'];
    $activity = $_POST['activity'];
    $collect = $_POST['collect'];
    $leader = $_POST['leader'];
    $texts = $_POST['texts'];
    $reader = $_POST['reader'];
    $theme = $_POST['theme'];
    $preacher = $_POST['preacher'];

    // Insert the data into the service table
    $sql = "INSERT INTO service (date, activity,collect, leader, texts, reader, theme, preacher) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and execute the statement
    if ($stmt = $con->prepare($sql)) {
        $stmt->bind_param('ssisssss', $date, $activity, $collect, $leader, $texts, $reader, $theme, $preacher);

        // Check if the execution was successful
        if ($stmt->execute()) {
            echo "New service added successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error: " . $con->error;
    }

    // Close the connection
    $con->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js">
    
</script>


    <!-- My CSS -->
    <link rel="stylesheet" href="style.css">
      <style>
             
             button {
      background-color: #28a745; /* Green color */
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 12px; /* Round corners */
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Optional shadow */
      transition: background-color 0.3s ease; /* Smooth hover effect */
    }
    
    button:hover {
      background-color: #218838; /* Darker green on hover */
    }

       
        .popup-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 90%;
            max-width: 600px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .close-btn {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close-btn:hover,
        .close-btn:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .form-container {
            max-width: 90%;
            width: 100%;
            margin: auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input:focus {
            border-color: #007bff;
            outline: none;
        }

        .submit-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        /* Table styles */
        .hostel-details-container {
            max-height: auto; /* Adjust as needed */
            overflow-y: auto;  /* Enable vertical scrolling */
            overflow-x: auto;  /* Enable horizontal scrolling */
            border: 1px solid #ccc;
            padding: 10px;
            white-space: nowrap; /* Prevent text from wrapping, which forces horizontal scrolling */
        }

        .hostel-details {
            height: auto;
            transition: opacity 0.5s ease-in-out;
        }

        .hidden {
            opacity: 0;
            pointer-events: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            table-layout: auto;
            display: block;  /* Ensures the table can scroll */
            overflow-x: auto;
            white-space: nowrap; /* Prevent wrapping of text in columns */
        }

        th, td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: left;
            min-width: 90px; /* Set a minimum width for each column */
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Last column for action buttons */
        th:last-child, td:last-child {
            width: 90px; /* Adjust width according to the button size */
                   padding-right: 140px;
               
        }

        tr:hover {
            background-color: #ddd;
        }

        /* Dark theme */
        body.dark-theme {
            background-color: #121212;
            color: #fff;
        }

        body.dark-theme table {
            border-color: #666;
        }

        body.dark-theme th {
            background-color: #333;
        }

        body.dark-theme tr:nth-child(even) {
            background-color: #333;
        }

        body.dark-theme tr:hover {
            background-color: #444;
        }

        @media screen and (max-width: 480px) {
            .table-responsive {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            table {
                min-width: 400px;
            }
        }

        /* Slide toggle button */
        .toggle-wrapper {
            position: relative;
            width: 60px;
            height: 30px;
            background-color: #ddd;
            border-radius: 15px;
            cursor: pointer;
        }

        .toggle-handle {
            position: absolute;
            top: 50%;
            left: 2px;
            width: 26px;
            height: 26px;
            background-color: #fff;
            border-radius: 50%;
            transition: transform 0.3s ease;
        }

        .logo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 150px;
            height: auto;
            margin-top: 60px;
            margin-left: 30px;
        }

        .logo-container img {
            max-width: 100%; /* Ensure the image doesn't exceed its container's width */
            height: auto; /* Maintain aspect ratio */
        }

        .toggle-wrapper.active .toggle-handle {
            transform: translateX(30px);
        }

        /* Responsive design */
        @media screen and (max-width: 480px) {
            .form-container {
                padding: 10px;
                    width:100%;
            }

            .popup-content { 
                    margin: 5% auto; /* Reduce the margin to ensure more space for the form */
        padding: 15px; /* Reduce padding to make more room */
        width: 95%; /* Ensure it takes up most of the screen width */
        max-height: 80vh; /* Limit height to avoid going off-screen */
        overflow-y: auto; /* Allow scrolling if content is too tall */
                     overflow-x: auto;
                    
            }
            .popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .popup-content {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            width: 60%;
        }

        .close-btn {
            float: right;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .form-container .form-group {
            margin-bottom: 15px;
        }

        .form-container .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-container .form-group input,
        .form-container .form-group textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        .submit-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .submit-btn:hover {
            background-color: #45a049;
        }

        .details-section {
            margin-top: 20px;
        }

        .styled-table {
            width: 100%;
            border-collapse: collapse;
        }

        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }

        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
            border: 1px solid #dddddd;
        }

        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        
        @media screen and (max-width: 480px) {
            .toggle-wrapper {
                width: 50px;
                height: 25px;
            }

            .toggle-handle {
                width: 22px;
                height: 22px;
            }

            #addHostelButton {
                font-size: 10px;
                padding: 10px 15px;
            }

            .submit-btn {
                padding: 8px 16px;
                font-size: 14px;
                    width:100%;
            }
        }
    </style>
        
    <title>service</title>
</head>
<body>
<?php include 'connect.php'; ?>

<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
              <div class="logo-container">
        <img src="logo.jpg" alt="Internhub Logo" width=80% ></div>
        <!--<span class="text">HostelHub</span>-->
    </a>
    <ul class="side-menu top">
        <li >
            <a href="dashboard.php">
                <i class='bx bxs-dashboard'></i>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <li class="active">
            <a href="trial.php" onclick="toggleApplications('bookings')">
                <i class='bx bxs-calendar-check'></i>
                <span class="text">Services</span>
            </a>
        </li>
        <li >
            <a href="upload_congregation_stats.php" onclick="toggleApplications('hostels')">
                <i class='bx bxs-home'></i>
                <span class="text">congregation</span>
            </a>
        </li>
        <li><a href="upload_activity_management.php" onclick="toggleApplications('hostels')">
                <i class='bx bxs-home'></i>
                <span class="text">activity</span>
            </a>
        </li>
       <li> <a href="upload_givings.php" onclick="toggleApplications('hostels')">
                <i class='bx bxs-home'></i>
                <span class="text">Givings</span>
            </a>
        </li>
    </ul>
    
    <ul class="side-menu">
        <li>
            <a href="#">
                <i class='bx bxs-cog'></i>
                <span class="text">Settings</span>
            </a>
        </li>
        <li>
            <a href="admin_logout.php" class="logout">
                <i class='bx bxs-log-out-circle'></i>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</section>

<!-- Add service -->
<button onclick="openPopup('addServicePopup')" class="btn btn-success rounded-pill">Add Service</button>

<div id="addServicePopup" class="popup">
    <div class="popup-content">
        <span class="close-btn" onclick="closePopup('addServicePopup')">&times;</span>
        <h2>Add Service</h2>
        <form action="add_service.php" method="post" enctype="multipart/form-data" class="form-container">
            <!-- Form fields -->
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" placeholder="Enter the date" required>
            </div>
            <div class="form-group">
                <label for="activity">Activity:</label>
                <input type="text" id="activity" name="activity" placeholder="Enter activity" required>
            </div>
            <div class="form-group">
                <label for="collect">Collect:</label>
                <input type="text" id="collect" name="collect" placeholder="Enter collect" required>
            </div>
            <div class="form-group">
                <label for="leader">Leader:</label>
                <input type="text" id="leader" name="leader" placeholder="Enter leader" required>
            </div>
            <div class="form-group">
                <label for="texts">Texts:</label>
                <input type="text" id="texts" name="texts" placeholder="Enter texts" required>
            </div>
            <div class="form-group">
                <label for="reader">Reader:</label>
                <input type="text" id="reader" name="reader" placeholder="Enter reader" required>
            </div>
            <div class="form-group">
                <label for="theme">Theme:</label>
                <input type="text" id="theme" name="theme" placeholder="Enter theme" required>
            </div>
            <div class="form-group">
                <label for="preacher">Preacher/Facilitator:</label>
                <input type="text" id="preacher" name="preacher" placeholder="Enter preacher/facilitator" required>
            </div>
            <div class="form-group">
                <label for="verger">Verger:</label>
                <input type="text" id="verger" name="verger" placeholder="Enter Verger" required>
            </div>
            <div class="form-group">
                <label for="treasurer">Treasurer:</label>
                <input type="text" id="treasurer" name="treasurer" placeholder="Enter Treasurer" required>
            </div>
            <div class="form-group">
                <label for="chaplain">Chaplain:</label>
                <input type="text" id="chaplain" name="chaplain" placeholder="Enter Chaplain" required>
            </div>
            <div class="form-group">
                <label for="expenses">Expenses:</label>
                <input type="number" id="expenses" name="expenses" step="0.01" placeholder="Enter Expenses" required>
            </div>
            <div class="form-group">
                <label for="received_by">Received By:</label>
                <input type="text" id="received_by" name="received_by" placeholder="Enter Received By" required>
            </div>
            <div class="form-group">
                <label for="brief_report">Brief Report:</label>
                <textarea id="brief_report" name="brief_report" placeholder="Enter Brief Report" required></textarea>
            </div>
            <div class="form-group">
                <label for="remarks">Remarks:</label>
                <textarea id="remarks" name="remarks" placeholder="Enter Remarks" required></textarea>
            </div>

            <button type="submit" name="add_service" class="submit-btn">Add Service</button>
        </form>
    </div>
</div>

<script>
    function closePopup(popupId) {
        document.getElementById(popupId).style.display = 'none';
    }

    function openPopup(popupId) {
        document.getElementById(popupId).style.display = 'block';
    }

    function toggleSection(sectionId) {
        var section = document.getElementById(sectionId);
        if (section.style.display === 'none' || section.style.display === '') {
            section.style.display = 'block';
        } else {
            section.style.display = 'none';
        }
    }
</script>

<?php
// Include database connection file
include 'connect.php';

// Initialize variables to store counts
$numBookings = 0;
$numHostels = 0;
$numStudents = 0;

// Fetch number of bookings
$bookings_query = "SELECT COUNT(*) AS numBookings FROM congregation_stats";
$bookings_result = $con->query($bookings_query);
if ($bookings_result) {
    $bookings_row = $bookings_result->fetch_assoc();
    $numBookings = $bookings_row["numBookings"];
} else {
    die("Error fetching bookings: " . $con->error);
}

// Fetch number of hostels
$hostels_query = "SELECT COUNT(*) AS numHostels FROM givings";
$hostels_result = $con->query($hostels_query);
if ($hostels_result) {
    $hostels_row = $hostels_result->fetch_assoc();
    $numHostels = $hostels_row["numHostels"];
} else {
    die("Error fetching hostels: " . $con->error);
}

// Fetch number of students
$students_query = "SELECT COUNT(*) AS numStudents FROM activity_management";
$students_result = $con->query($students_query);
if ($students_result) {
    $students_row = $students_result->fetch_assoc();
    $numStudents = $students_row["numStudents"];
} else {
    die("Error fetching students: " . $con->error);
}
?>

<!-- Display fetched data -->
<div>
    <button onclick="toggleSection('givings-section')" class="btn btn-primary">Toggle Givings</button>
    <button onclick="toggleSection('activityManagement-section')" class="btn btn-primary">Toggle Activity Management</button>
</div>

<div id="givings-section" class="details-section" style="display: none;">
    <h2>Givings</h2>
    <table class="styled-table" id="givings-table">
        <thead>
            <tr>
                <th>Offertory</th>
                <th>Thanksgiving</th>
                <th>Tithe</th>
                <th>Children</th>
                <th>Others</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $givings_details_query = "SELECT * FROM givings";
            $givings_details_result = $con->query($givings_details_query);
            if ($givings_details_result->num_rows > 0) {
                while ($row = $givings_details_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['offertory']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['thanksgiving']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['tithe']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['children']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['others']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['total']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No givings found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<div id="activityManagement-section" class="details-section" style="display: none;">
    <h2>Activity Management</h2>
    <table class="styled-table" id="activityManagement-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Activity</th>
                <th>Collect</th>
                <th>Leader</th>
                <th>Texts</th>
                <th>Reader</th>
                <th>Theme</th>
                <th>Preacher</th>
                <th>Verger</th>
                <th>Treasurer</th>
                <th>Chaplain</th>
                <th>Expenses</th>
                <th>Received By</th>
                <th>Brief Report</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $activity_details_query = "SELECT * FROM activity_management";
            $activity_details_result = $con->query($activity_details_query);
            if ($activity_details_result->num_rows > 0) {
                while ($row = $activity_details_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['activity']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['collect']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['leader']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['texts']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['reader']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['theme']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['preacher']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['verger']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['treasurer']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['chaplain']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['expenses']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['received_by']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['brief_report']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['remarks']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='15'>No activities found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
