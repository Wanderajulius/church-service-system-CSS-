<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Report</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-group {
            margin-top: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin: 15px auto;
        }

        .form-group input,
        .form-group select {
            width: 70%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #007bff;
            outline: none;
        }

        .submit-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<form action="generate_pdf.php" method="post" class="form-container">
    <div class="form-group">
        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date">
    </div>
    <div class="form-group">
        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date">
    </div>
    <div class="form-group">
            <label for="activity">Activity:</label>
            <select id="activity" name="activity" required>
                <option value="" disabled selected>Select an activity</option>
                <option value="Sunday Service">Sunday Service</option>
                <option value="Bible Study">Bible Study</option>
                <option value="Prayer Meeting">Prayer Meeting</option>
                <option value="Youth Fellowship">Baptism</option>
                <option value="Youth Fellowship">Movie Night</option>
                <option value="Youth Fellowship">Focus Fellowship</option>
                <option value="Youth Fellowship">Choir Practice</option>
                <option value="Youth Fellowship">Confirmation Class</option>
                <option value="Youth Fellowship">Outreach</option>
                <option value="Youth Fellowship">Guidance And Counciling</option>
                <!-- Add more options as needed -->
            </select>
    </div>

    <button type="submit" class="submit-btn">Generate PDF</button>
</form>
</body>
</html>
