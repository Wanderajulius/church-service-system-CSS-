<?php
// Include your database connection
include 'connect.php'; // Make sure this file contains the $con variable for database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from form
    $date = $_POST['date'];
    $activity = $_POST['activity'];
    $congregation_male = $_POST['congregation_male'];
    $congregation_female = $_POST['congregation_female'];
    $communicants_male = $_POST['communicants_male'];
    $communicants_female = $_POST['communicants_female'];
    $children_male = $_POST['children_male'];
    $children_female = $_POST['children_female'];

    // Update query
    $update_query = "UPDATE congregation_stats SET 
        congregation_male='$congregation_male', 
        congregation_female='$congregation_female', 
        communicants_male='$communicants_male', 
        communicants_female='$communicants_female', 
        children_male='$children_male', 
        children_female='$children_female', 
        
        WHERE date='$date' AND activity='$activity'";

    if ($con->query($update_query) === TRUE) {
        echo "<script>
            alert('Record updated successfully!');
            window.location.href = 'upload_congregation_stats.php'; // Redirect after alert
        </script>";
        exit(); // Stop further script execution
    } else {
        echo "Error updating record: " . $con->error;
    }
}

// Fetch current data to populate the form
$date = $_GET['date'];
$activity = $_GET['activity'];
$fetch_query = "SELECT * FROM congregation_stats WHERE date='$date' AND activity='$activity'";
$result = $con->query($fetch_query);
$row = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Giving</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include your CSS file -->
    <style>
        h2{
text-align:center;
        }
        .form-group ,h2{
            margin-top: 15px;
        justify-content:center;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            /* margin: 15px auto; */
            width: 100%;
            justify-content:center;
        }

        .form-group input,
        .form-group select {
            width: 70%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #007bff;
            outline: none;
        }

        .submit-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }
    </style>

</head>
<body>
    <h2>Update congregation stats</h2>
    <form action="update_congregation.php" method="post" class="form-container">
    <div class="form-group">
        <input type="hidden" name="date" value="<?php echo $row['date']; ?>">
        <input type="hidden" name="activity" value="<?php echo $row['activity']; ?>">
    </div>
    <div class="form-group">
        <div>
            <label for="congregation_male">congregation male :</label>
            <input type="number" name="congregation_male" value="<?php echo $row['congregation_male']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="congregation_female">congregation female :</label>
            <input type="number" name="congregation_female" value="<?php echo $row['congregation_female']; ?>" required>
        </div>
    </div>

    <div class="form-group">
        <div>
            <label for="communicants_male">communicants male :</label>
            <input type="number" name="communicants_male" value="<?php echo $row['communicants_male']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="communicants_female">communicants female :</label>
            <input type="number" name="communicants_female" value="<?php echo $row['communicants_female']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="children_male">children male :</label>
            <input type="number" name="children_male" value="<?php echo $row['children_male']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="children_female">children female:</label>
            <input type="text" name="children_female" value="<?php echo $row['children_female']; ?>" required>
        </div>
    </div>
    <button type="submit" class="submit-btn">Update Congregation</button>
    </form>
</body>
</html>
