<?php
// Include your database connection
include 'connect.php'; // Make sure this file contains the $con variable for database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from form
    $date = $_POST['date'];
    $activity = $_POST['activity'];
    $offertory = $_POST['offertory'];
    $thanksgiving = $_POST['thanksgiving'];
    $tithe = $_POST['tithe'];
    $children = $_POST['children'];
    $others = $_POST['others'];
    $verger = $_POST['verger'];
    $treasurer = $_POST['treasurer'];
    $chaplain = $_POST['chaplain'];
    $received_by = $_POST['received_by'];

    // Update query
    $update_query = "UPDATE givings SET 
        offertory='$offertory', 
        thanksgiving='$thanksgiving', 
        tithe='$tithe', 
        children='$children', 
        others='$others', 
        verger='$verger', 
        treasurer='$treasurer', 
        chaplain='$chaplain', 
        received_by='$received_by'
        WHERE date='$date' AND activity='$activity'";

    if ($con->query($update_query) === TRUE) {
        echo "<script>
            alert('Record updated successfully!');
            window.location.href = 'upload_givings.php'; // Redirect after alert
        </script>";
        exit(); // Stop further script execution
    } else {
        echo "Error updating record: " . $con->error;
    }
}

// Fetch current data to populate the form
$date = $_GET['date'];
$activity = $_GET['activity'];
$fetch_query = "SELECT * FROM givings WHERE date='$date' AND activity='$activity'";
$result = $con->query($fetch_query);
$row = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Giving</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include your CSS file -->
    <style>
        h2{
text-align:center;
        }
        .form-group ,h2{
            margin-top: 15px;
        justify-content:center;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            /* margin: 15px auto; */
            width: 100%;
            justify-content:center;
        }

        .form-group input,
        .form-group select {
            width: 70%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #007bff;
            outline: none;
        }

        .submit-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }
    </style>

</head>
<body>
    <h2>Update Giving Record</h2>
    <form action="update_givings.php" method="post" class="form-container">
    <div class="form-group">
        <input type="hidden" name="date" value="<?php echo $row['date']; ?>">
        <input type="hidden" name="activity" value="<?php echo $row['activity']; ?>">
    </div>
    <div class="form-group">
        <div>
            <label for="offertory">Offertory (UGX):</label>
            <input type="number" name="offertory" value="<?php echo $row['offertory']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="thanksgiving">Thanksgiving (UGX):</label>
            <input type="number" name="thanksgiving" value="<?php echo $row['thanksgiving']; ?>" required>
        </div>
    </div>

    <div class="form-group">
        <div>
            <label for="tithe">Tithe (UGX):</label>
            <input type="number" name="tithe" value="<?php echo $row['tithe']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="children">Children (UGX):</label>
            <input type="number" name="children" value="<?php echo $row['children']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="others">Others (UGX):</label>
            <input type="number" name="others" value="<?php echo $row['others']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="verger">Verger:</label>
            <input type="text" name="verger" value="<?php echo $row['verger']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="treasurer">Treasurer:</label>
            <input type="text" name="treasurer" value="<?php echo $row['treasurer']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="chaplain">Chaplain:</label>
            <input type="text" name="chaplain" value="<?php echo $row['chaplain']; ?>" required>
        </div>
    </div>
    <div class="form-group">
        <div>
            <label for="received_by">Received By:</label>
            <input type="text" name="received_by" value="<?php echo $row['received_by']; ?>" required>
        </div>
    </div>
    <button type="submit" class="submit-btn">Update Giving</button>
    </form>
</body>
</html>
