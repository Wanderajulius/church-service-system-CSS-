<?php
require('connect.php');
// Include the TCPDF library
require_once('C:\xampp\htdocs\advent_chapel\vendor\tecnickcom\tcpdf\tcpdf.php');

// Check the database connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Function to fetch data from a given table and return as HTML
function fetch_table_data($con, $table_name, $headers, $columns, $start_date, $end_date, $activity) {
    $sql = "SELECT * FROM $table_name WHERE 1=1";
    
    // Add date range filter if both start_date and end_date are provided
    if (!empty($start_date) && !empty($end_date)) {
        $sql .= " AND date BETWEEN ? AND ?";
    }
    
    // Add activity filter if activity is provided
    if (!empty($activity)) {
        $sql .= " AND activity = ?";
    }

    $stmt = $con->prepare($sql);
    
    // Bind parameters based on provided inputs
    if (!empty($start_date) && !empty($end_date) && !empty($activity)) {
        $stmt->bind_param("sss", $start_date, $end_date, $activity);
    } elseif (!empty($start_date) && !empty($end_date)) {
        $stmt->bind_param("ss", $start_date, $end_date);
    } elseif (!empty($activity)) {
        $stmt->bind_param("s", $activity);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();

    if (!$result) {
        die("Query failed: " . $con->error);
    }

    $html = "<h1>$table_name</h1>
    <table border=\"1\" cellpadding=\"5\">
    <tr>";

    // Adding headers
    foreach ($headers as $header) {
        $html .= "<th>$header</th>";
    }
    $html .= "</tr>";

    // Adding data rows
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $html .= "<tr>";
            foreach ($columns as $column) {
                $html .= "<td>" . $row[$column] . "</td>";
            }
            $html .= "</tr>";
        }
    } else {
        $html .= "<tr><td colspan=\"" . count($headers) . "\">No data found</td></tr>";
    }

    $html .= "</table>";
    return $html;
}

// Get the start date, end date, and activity from the POST request, if they exist
$start_date = isset($_POST['start_date']) ? $_POST['start_date'] : '';
$end_date = isset($_POST['end_date']) ? $_POST['end_date'] : '';
$activity = isset($_POST['activity']) ? $_POST['activity'] : '';

// Create a new PDF document
$pdf = new TCPDF();

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Your Name');
$pdf->SetTitle('Database PDF Report');
$pdf->SetSubject('PDF Generation from Database');
$pdf->SetKeywords('TCPDF, PDF, database, report');

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
$pdf->AddPage('L'); // 'L' for landscape orientation

// Set font
$pdf->SetFont('helvetica', '', 12);

// Fetch and add data from each table
$activity_headers = ['Date', 'Activity', 'Leader', 'Texts', 'Reader', 'Theme', 'Preacher', 'Expenses', 'Brief Report', 'Remarks'];
$activity_columns = ['date', 'activity', 'leader', 'texts', 'reader', 'theme', 'preacher', 'expenses', 'brief_report', 'remarks'];
$pdf->writeHTML(fetch_table_data($con, 'activity', $activity_headers, $activity_columns, $start_date, $end_date, $activity), true, false, true, false, '');

$congregation_stats_headers = ['Date', 'Congregation Male', 'Congregation Female', 'Communicants Male', 'Communicants Female', 'Children Male', 'Children Female','Congregation_Total'];
$congregation_stats_columns = ['date', 'congregation_male', 'congregation_female', 'communicants_male', 'communicants_female', 'children_male', 'children_female','congregation_total'];
$pdf->AddPage('L'); // Add new page for new table
$pdf->writeHTML(fetch_table_data($con, 'congregation_stats', $congregation_stats_headers, $congregation_stats_columns, $start_date, $end_date, $activity), true, false, true, false, '');

$givings_headers = ['Date','Activity', 'Offertory', 'Thanksgiving', 'Tithe', 'Children', 'Others', 'Total', 'Verger', 'Treasurer', 'Chaplain', 'Received by'];
$givings_columns = ['date','activity', 'offertory', 'thanksgiving', 'tithe', 'children', 'others', 'total', 'verger', 'treasurer', 'chaplain', 'received_by'];
$pdf->AddPage('L'); // Add new page for new table
$pdf->writeHTML(fetch_table_data($con, 'givings', $givings_headers, $givings_columns, $start_date, $end_date, $activity), true, false, true, false, '');

// Close the database connection
$con->close();

// Output the PDF
$pdf->Output('Advent_Chapel Report.pdf', 'I'); // Change 'I' to 'D' for download
?>
