<?php
// Include your database connection
include 'connect.php'; // Ensure this file connects to your database

// Check if the request is a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get date and activity from URL
    $date = $_GET['date'];
    $activity = $_GET['activity'];

    // Delete query
    $delete_query = "DELETE FROM givings WHERE date='$date' AND activity='$activity'";

    if ($con->query($delete_query) === TRUE) {
        echo 
        "<script>
            alert('Record deleted successfully');
            setTimeout(function() {
                window.location.href = 'upload_givings.php';
            }, 1000); // Redirect after 1 second
        </script>";
    } else {
        echo "Error deleting record: " . $con->error;
    }
}
?>
