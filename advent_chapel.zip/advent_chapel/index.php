<?php
session_start();
include_once('connect.php');

$error_message = '';

// Check if the admin is already logged in
if(isset($_SESSION['admin_logged_in'])) {
    // If logged in, redirect to the dashboard
    header("Location: dashboard.php");
    exit();
}

// If the login form is submitted
if(isset($_POST['username']) && isset($_POST['password'])) {

    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    // Set default admin username and password
    $default_admin_username = 'admin';
    $default_admin_password = 'admin123'; // Change the default password here

    // Check if the entered credentials match the default admin credentials
    if($username === $default_admin_username && $password === $default_admin_password) {
        // Set session variable to indicate admin is logged in
        $_SESSION['admin_logged_in'] = true;
        header("Location: dashboard.php");
        exit();
    } else {
        // Display error message if login fails
        $error_message = "Invalid username or password. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body, html {
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background-color: #f5f5f5;
    }
    .navbar {
      width: 100%;
    }
    .login-container {
      max-width: 400px;
      width: 100%;
      padding: 20px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .login-title {
      margin-bottom: 20px;
    }
  </style>
</head>
<body>

<!-- <nav class="navbar navbar-expand-lg navbar-light bg-success">
  <div class="container-fluid">
    <a class="navbar-brand text-white" href="index.php">
      <i class="fas fa-arrow-left"></i> Back to Home
    </a>
  </div>
</nav> -->

<div class="login-container">
  <h2 class="login-title text-center">Church Administrator Login</h2>
  <?php if ($error_message): ?>
  <div class="alert alert-danger" role="alert">
    <?php echo htmlspecialchars($error_message); ?>
  </div>
  <?php endif; ?>
  <form method="post" action="index.php">
    <div class="mb-3">
      <label for="username" class="form-label">Username</label>
      <div class="input-group">
        <div class="input-group-text"><i class="fas fa-user"></i></div>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">Password</label>
      <div class="input-group">
        <div class="input-group-text"><i class="fas fa-lock"></i></div>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
    </div>
    <button type="submit" class="btn btn-primary w-100" name="login">Login</button>
  </form>
</div>

</body>
</html>
